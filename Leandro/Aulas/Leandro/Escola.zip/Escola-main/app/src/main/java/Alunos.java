public class Alunos {

    String nomeAt;
    String cursoAt;

    public Alunos(String namePar ,String coursePar){
        this.nomeAt = namePar;
        this.cursoAt = coursePar;
    }
    public String getNome(){
        return nomeAt;
    }

    public String getCursoAt() {
        return cursoAt;
    }
}
