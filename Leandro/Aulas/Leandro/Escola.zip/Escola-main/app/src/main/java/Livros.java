public class Livros {

    String tituloAt;
    String subituloAt;

    public Livros(){

    }

    public  Livros(String t, String st){
        this.tituloAt = t;
        this.subituloAt = st;
    }

    public void setTituloAt(String ttl){
        this.tituloAt = ttl;
    }

    public void setSubituloAt(String stl){
        this.subituloAt = stl;
    }

    public String getTituloAt(){
        return tituloAt;
    }

    public String getSubituloAt(){
        return subituloAt;
    }
}
